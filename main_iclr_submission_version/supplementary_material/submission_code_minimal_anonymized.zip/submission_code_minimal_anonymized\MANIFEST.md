﻿# Manifest

Included directories:

- `00_shared/core_losses_and_solvers`
- `00_shared/model_training`
- `01_adversarial_attack/burgers`
- `01_adversarial_attack/darcy_flow`
- `01_adversarial_attack/navier_stokes`
- `02_adversarial_training/burgers`
- `02_adversarial_training/darcy_flow`
- `02_adversarial_training/navier_stokes`

Excluded from this minimal package:

- dataset generation;
- plotting and figure rendering;
- table and metric-summary builders;
- post-training diagnostics;
- robustness-only probes;
- timing and memory experiments;
- mechanism and ablation studies;
- shell entrypoints and scheduler scripts.

