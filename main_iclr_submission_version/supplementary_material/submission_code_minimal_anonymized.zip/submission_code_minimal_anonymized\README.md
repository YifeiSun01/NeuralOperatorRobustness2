﻿# Minimal Anonymous Code Supplement

This archive contains the minimal code needed for the submission's core
experiments:

- shared adversarial losses, solvers, and training utilities;
- model training code for Burgers, Darcy flow, and Navier-Stokes models;
- adversarial attack scripts for Burgers, Darcy flow, and Navier-Stokes;
- adversarial training scripts for Burgers, Darcy flow, and Navier-Stokes.

The archive intentionally excludes dataset-generation scripts, plotting scripts,
table builders, diagnostics, timing/memory probes, mechanism/ablation studies,
shell launchers, and machine-specific configuration.

All private paths and identifying information have been anonymized.

